<section class="sectionSliderSmall pastpresidents">
        <div class="container">
            <div class="sliderHeader">
             <h3 class="darkblue">PAST PRESIDENTS</h3>
            </div>

            <div class="swiper-container-small1">
                <!-- swiper slides -->
                <div class="swiper-wrapper " id="lightgallery1">
                    <div class="swiper-slide" data-src="./assets/img/Srijana-Rana-3.jpg">
                        <a href="">
                            <div class="slidersmall_contents">
                                <div class="slidersmall_image">
                                    <img src="./assets/img/Srijana-Rana-3.jpg" alt="banner" />
                                </div>
                                <div class="slidersmall_content">
                                    <div class="newsDate">april 6, 2018</div>
                                    <h4>President Name</h4>
                                    <div class="degination_title">President</div>
                                </div>
                                
                            </div>
                        </a>
                    </div>

                    <div class="swiper-slide" data-src="./assets/img/Srijana-Rana-3.jpg">
                        <a href="">
                            <div class="slidersmall_contents">
                                <div class="slidersmall_image">
                                    <img src="./assets/img/Srijana-Rana-3.jpg" alt="banner" />
                                </div>
                                <div class="slidersmall_content">
                                    <div class="newsDate">april 6, 2018</div>
                                    <h4>President Name</h4>
                                    <div class="degination_title">President</div>
                                </div>
                               
                            </div>
                        </a>
                    </div>

                    <div class="swiper-slide" data-src="./assets/img/Srijana-Rana-3.jpg">
                        <a href="">
                            <div class="slidersmall_contents">
                                <div class="slidersmall_image">
                                    <img src="./assets/img/Srijana-Rana-3.jpg" alt="banner" />
                                </div>
                                <div class="slidersmall_content">
                                    <div class="newsDate">april 6, 2018</div>
                                    <h4>President Name</h4>
                                    <div class="degination_title">President</div>
                                </div>
                                
                            </div>
                        </a>
                    </div>

                    <div class="swiper-slide" data-src="./assets/img/Srijana-Rana-3.jpg">
                        <a href="">
                            <div class="slidersmall_contents">
                                <div class="slidersmall_image">
                                    <img src="./assets/img/Srijana-Rana-3.jpg" alt="banner" />
                                </div>
                                <div class="slidersmall_content">
                                    <div class="newsDate">april 6, 2018</div>
                                    <h4>President Name</h4>
                                </div>
                                
                            </div>
                        </a>
                    </div>

                    <div class="swiper-slide" data-src="./assets/img/Srijana-Rana-3.jpg">
                        <a href="">
                            <div class="slidersmall_contents">
                                <div class="slidersmall_image">
                                    <img src="./assets/img/Srijana-Rana-3.jpg" alt="banner" />
                                </div>
                                <div class="slidersmall_content">
                                    <div class="newsDate">april 6, 2018</div>
                                    <h4>President Name</h4>
                                </div>
                                
                            </div>
                        </a>
                    </div>
                </div>
                <!-- !swiper slides -->
            </div>

            <!-- next / prev arrows -->
            <div class="swiper-button-prev swiper-button-next-small1"></div>
            <div class="swiper-button-next swiper-button-prev-small1"></div>
            <!-- !next / prev arrows -->
        </div>
    </section>
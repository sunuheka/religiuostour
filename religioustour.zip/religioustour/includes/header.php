<header>
<button onclick="topFunction()" id="myBtn" title="Go to top">Top</button>
<!-- <div class="container">
  <div class="headerTop d-flex ">
   
    <div class="headerTopLeft"> 
      <span class="headerContacts"><i class="icon icon-mail"></i>hello@yoursite.com</span> 
      <span class="headerContacts"><i class="icon icon-time"></i>Mon - Sat: 9.30am To 10.00pm</span> 
    </div>
    <div class="headerTopRight">
       <span class="headerSocialicons"> 
         <a href="" class="fbIcon headerSocialicons_link"><span class="icon icon-facebook"></span></a>
         <a href="" class="twIcon headerSocialicons_link"><span class="icon icon-twitter"></span></a>
         <a href="" class="inIcon headerSocialicons_link"><span class="icon icon-instagram"></span></a>
         <a href="" class="inIcon headerSocialicons_link"><span class="icon icon-pinterest"></span></a>
         <a href="" class="ytIcon headerSocialicons_link"><span class="icon icon-linkedln"></span></a>
       </span>
       <a href="callto:" class="ml-3">+099 12345678</a>
    </div>
  </div>
  </div> -->

  <?php include 'includes/nav.php';?>    


</header>

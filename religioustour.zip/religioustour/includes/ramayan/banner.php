<section class="sectionBanner">
        <div class="project_banner-image">
            <!-- <div class="overlay-bg"></div> -->
            <!-- <div class="container"> -->
                <div class="swiper-container">
                    <!-- swiper slides -->
                    <div class="swiper-wrapper">
                        <div class="swiper-slide" ">                        
                            <div class="image-layer" style="background-image: url('./assets/img/bodhnath-stupa.jpg');"></div>
                            <div class="overlay"></div>
                            <div class="banner_contents">
                                <h1 class="h1">Welcome To</h1>
                                <h2 class="h1 textbg">Ramayan CIRCUIT</h2>
                            </div>
                        </div>

                        <div class="swiper-slide">
                            <div class="image-layer" style="background-image: url('./assets/img/ramyan.jpg');"></div>
                            <div class="overlay"></div>
                            <div class="banner_contents">
                                <h1 class="h1">Explore To</h1>
                                <h2 class="h1 textbg">Ramayan CIRCUIT</h2>
                            </div>
                        </div>
                    </div>
                    <!-- !swiper slides -->
                </div>

                <!-- next / prev arrows -->
                <div class="swiper-button-next swiper-button-next-big"><span>Next</span></div>
                <div class="swiper-button-prev swiper-button-prev-big"><span>Prev</span></div>
                <!-- !next / prev arrows -->
            <!-- </div> -->
        </div>
    </section>

<section class="footer">
<div id="partner" class="footerTop">
            <div class="container">
                <div class="row">
                    <div class="col-sm-12">
                        <div class="blockTitle text-center">
                            <div class="leadText">Partner</div>
                            <h2>Our Members</h2>
                        </div>

                        <div class="partnerList">
                        <div class="swiper-container-small1">
                            <div class="swiper-wrapper">
                                <div class="swiper-slide">
                                    <a href="http://nicci.org/" class="partnerItem">
                                        <img src="./assets/img/logo.jpg" alt="nicci">
</a>
                                </div>
                                <div class="swiper-slide">
                                    <a href="http://nicci.org/" class="partnerItem">
                                        <img src="./assets/img/logo.jpg" alt="nicci">
</a>
                                </div>
                                <div class="swiper-slide">
                                    <a href="http://nicci.org/" class="partnerItem">
                                        <img src="./assets/img/logo.jpg" alt="nicci">
</a>
                                </div>
                                <div class="swiper-slide">
                                    <a href="http://nicci.org/" class="partnerItem">
                                        <img src="./assets/img/logo.jpg" alt="nicci">
</a>
                                </div>
                            </div>
                            <!-- next / prev arrows -->
                            <div class="swiper-button-next swiper-button-next-small1"><span class="icon icon-arrow"></span></div>
                            <div class="swiper-button-prev swiper-button-prev-small1"><span class="icon icon-arrow"></span></div>
                            <!-- !next / prev arrows -->
                        </div>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
</section>
<section class="sectionOffers" style="background-image: url('./assets/img/monastery.png');">
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                <div class="blockHeading text-center">
                    <div class="leadText">Itinerary</div>
                    <h2 class="h2">Itinerary Tour With Budhhist Special Train</h2>
                </div>
                </div>
                <div class="col-sm-12">
<div class="widget-inner">
     <div class="offers-item">
         <a href="" class="item-inner">
            <div class="item-photo">
                <img src="./assets/img/Boudhanath.jpg" alt="">
                <div class="tag"><span class="tagtext">Day 01</span></div>
            </div>
            <div class="item-desc">
                <h3>Bodh Gaya Tourism Bodh Gaya Pilgrimage Tour</h3>
                <p>Bodhgaya is where Buddhism began. All pilgrims and Buddhism followers are fond of this place and the legend attached to it </p>
                <span class="btn-link">READ MORE</span>
            </div>
        </a>
    </div> 
    <div class="offers-item">
        <a href="" class="item-inner">
            <div class="item-photo">
                <img src="./assets/img/Boudhanath.jpg" alt="">
                <div class="tag"><span class="tagtext">Day 02</span></div>
            </div>
            <div class="item-desc">
                <h3>Bodh Gaya Tourism Bodh Gaya Pilgrimage Tour</h3>
                <p>Bodhgaya is where Buddhism began. All pilgrims and Buddhism followers are fond of this place and the legend attached to it </p>
                <span class="btn-link">READ MORE</span>
            </div>
        </a>
    </div>
    
    <div class="offers-item">
        <a href="" class="item-inner">
            <div class="item-photo">
            <img src="./assets/img/mahabharat.jpg" alt="">
            <div class="tag"><span class="tagtext">Day 03</span></div>
            </div>
            <div class="item-desc">
                <h3>Bodh Gaya Tourism Bodh Gaya Pilgrimage Tour</h3>
                <p>Bodhgaya is where Buddhism began. All pilgrims and Buddhism followers are fond of this place and the legend attached to it </p>
                <span class="btn-link">READ MORE</span>
            </div>
        </a>
    </div>
    <div class="offers-item">
        <a href="" class="item-inner">
            <div class="item-photo">
                <img src="./assets/img/Lobby.jpg" alt="">
                <div class="tag"><span class="tagtext">Day 04</span></div>
            </div>
            <div class="item-desc">
                <h3>Bodh Gaya Tourism Bodh Gaya Pilgrimage Tour</h3>
                <p>Bodhgaya is where Buddhism began. All pilgrims and Buddhism followers are fond of this place and the legend attached to it </p>
                <span class="btn-link">READ MORE</span>
            </div>
        </a>
    </div>

    <div class="offers-item">
        <a href="" class="item-inner">
            <div class="item-photo" >
                <img src="./assets/img/shivshakti.jpg" alt="">
                <div class="tag"><span class="tagtext">Day 05</span></div>
            </div>
            <div class="item-desc">
                <h3>Bodh Gaya Tourism Bodh Gaya Pilgrimage Tour</h3>
                <p>Bodhgaya is where Buddhism began. All pilgrims and Buddhism followers are fond of this place and the legend attached to it </p>
                <span class="btn-link">READ MORE</span>
            </div>
        </a>
    </div>

    <div class="offers-item">
        <a href="" class="item-inner">
            <div class="item-photo" >
                <img src="./assets/img/shivshakti.jpg" alt="">
                <div class="tag"><span class="tagtext">Day 06</span></div>
            </div>
            <div class="item-desc">
                <h3>Bodh Gaya Tourism Bodh Gaya Pilgrimage Tour</h3>
                <p>Bodhgaya is where Buddhism began. All pilgrims and Buddhism followers are fond of this place and the legend attached to it </p>
                <span class="btn-link">READ MORE</span>
            </div>
        </a>
    </div>

    <div class="offers-item">
        <a href="" class="item-inner">
            <div class="item-photo" >
                <img src="./assets/img/shivshakti.jpg" alt="">
                <div class="tag"><span class="tagtext">Day 07</span></div>
            </div>
            <div class="item-desc">
                <h3>Bodh Gaya Tourism Bodh Gaya Pilgrimage Tour</h3>
                <p>Bodhgaya is where Buddhism began. All pilgrims and Buddhism followers are fond of this place and the legend attached to it </p>
                <span class="btn-link">READ MORE</span>
            </div>
        </a>
    </div>

    <div class="offers-item">
        <a href="" class="item-inner">
            <div class="item-photo" >
                <img src="./assets/img/shivshakti.jpg" alt="">
                <div class="tag"><span class="tagtext">Day 08</span></div>
            </div>
            <div class="item-desc">
                <h3>Bodh Gaya Tourism Bodh Gaya Pilgrimage Tour</h3>
                <p>Bodhgaya is where Buddhism began. All pilgrims and Buddhism followers are fond of this place and the legend attached to it </p>
                <span class="btn-link">READ MORE</span>
            </div>
        </a>
    </div>
 </div>
                </div>
            </div>
        </div>
    </section>

<section id="map" class="sectionMap">
        <div class="container">
            <div class="blockHeading text-center">
                <div class="leadText">Map</div>
                <h2 class="h2">Famouse Circuit Attractions</h2>
            </div>
        </div>
        <div class="map">
            <img src="./assets/img/map.png" alt="">
        </div>
        
    </section>
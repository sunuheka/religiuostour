<section id="gallery" class="sectionGallery">
    <div class="container">
        <div class="blockHeading text-center">
            <div class="leadText">Gallery</div>
            <h2 class="h2">Discover The Budhhist Circuits</h2>
        </div>

        <div class="row grid" id="lightgallery">
            <!-- <div class="grid-sizer"></div> -->
            <div class="col-sm-4 grid-item" data-src="./assets/img/image.png">
                <a href="" class="galleryImage">
                <figure>
                    <img src="./assets/img/image.png" alt="image">
                </figure>
                    <div class="galleryContent">Nepal Buddhist Relegion</div>
                </a>
            </div>
            <div class="col-sm-4 grid-item" data-src="./assets/img/image.png">
                <a href="" class="galleryImage">
                    <figure>
                        <img src="./assets/img/image.png" alt="">
                    </figure>
                    <div class="galleryContent">Nepal Buddhist Relegion</div>
                </a>
            </div>
            <div class="col-sm-4 grid-item" data-src="./assets/img/ram.png">
                <a href="" class="galleryImage">
                    <figure>
                        <img src="./assets/img/ram.png" alt="">
                    </figure>
                    <div class="galleryContent">Nepal Buddhist Relegion</div>
                </a>
            </div>
            <div class="col-sm-4 grid-item" data-src="./assets/img/image.png">
                <a href="" class="galleryImage">
                    <figure>
                        <img src="./assets/img/image.png" alt="">
                    </figure>
                    <div class="galleryContent">Nepal Buddhist Relegion</div>
                </a>
            </div>
            <div class="col-sm-4 grid-item" data-src="./assets/img/img.png">
                <a href="" class="galleryImage">
                    <figure>
                        <img src="./assets/img/img.png" alt="">
                    </figure>
                    <div class="galleryContent">Nepal Buddhist Relegion</div>
                </a>
            </div>
            <div class="col-sm-4 grid-item" data-src="./assets/img/Boudhanath.jpg">
                <a href="" class="galleryImage">
                    <figure>
                        <img src="./assets/img/Boudhanath.jpg" alt="">
                    </figure>
                    <div class="galleryContent">Nepal Buddhist Relegion</div>
                </a>
            </div>
        </div>
    </div>
</section>

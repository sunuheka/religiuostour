<section class="sectionVideo" style="background-image: url('./assets/img/Manoj Poudel 17.JPG');">
<div class="overlay"></div>
<div class="swiper-container-video container">
    <div class="swiper-wrapper">
    <?php for( $i=1; $i <= 3; $i++ ) { ?>
    <div class="swiper-slide">
        <div class="video-content" >
            <div style="max-width: 450px">
            <h2>Any Video</h2>
            <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Commodi iure facere aut debitis inventore ipsa? Sed nam ipsam praesentium aut, sapiente odit eius, voluptates nobis unde voluptatem sequi, officiis atque.</p>
            </div>
        </div>
        <div class="video-iframe">
            <iframe height="345" src="https://www.youtube.com/embed/tgbNymZ7vqY?autoplay=0&mute=1">
            </iframe>
        </div>
    </div>
    <?php } ?>
</div>
<!-- Add Pagination -->
<div class="swiper-pagination-video"></div>
</div>
</section>
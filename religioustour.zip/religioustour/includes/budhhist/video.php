<section class="sectionVideo" style="background-image: url('./assets/img/monastery.png');">
<div class="swiper-container-video container">
    <div class="swiper-wrapper">
    <div class="swiper-slide">
        <div class="row">
        <div class="col-sm-6" style="padding-right: 100px">
            <h2>Any Video</h2>
            <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Commodi iure facere aut debitis inventore ipsa? Sed nam ipsam praesentium aut, sapiente odit eius, voluptates nobis unde voluptatem sequi, officiis atque.</p>
        </div>
        <div class="col-sm-6">
            <iframe width="420" height="345" src="https://www.youtube.com/embed/tgbNymZ7vqY?autoplay=1&mute=1">
            </iframe>
        </div>
        </div>
    </div>
    <div class="swiper-slide">
        <div class="row">
        <div class="col-sm-6" style="padding-right: 100px">
            <h2>Any Video</h2>
            <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Commodi iure facere aut debitis inventore ipsa? Sed nam ipsam praesentium aut, sapiente odit eius, voluptates nobis unde voluptatem sequi, officiis atque.</p>
        </div>
        <div class="col-sm-6">
            <iframe width="420" height="345" src="https://www.youtube.com/embed/tgbNymZ7vqY?autoplay=1&mute=1">
            </iframe>
        </div>
        </div>
    </div>
    <div class="swiper-slide">
        <div class="row">
        <div class="col-sm-6" style="padding-right: 100px">
            <h2>Any Video</h2>
            <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Commodi iure facere aut debitis inventore ipsa? Sed nam ipsam praesentium aut, sapiente odit eius, voluptates nobis unde voluptatem sequi, officiis atque.</p>
        </div>
        <div class="col-sm-6">
            <iframe width="420" height="345" src="https://www.youtube.com/embed/tgbNymZ7vqY?autoplay=1&mute=1">
            </iframe>
        </div>
        </div>
    </div>
</div>
<!-- Add Pagination -->
<div class="swiper-pagination"></div>
</div>
</section>
<section class="sectionTestimonial">
        <div class="container">
            <div class="blockHeading text-center">
                <div class="leadText">Testimonial</div>
                <h2 class="h2">Our Client's Words</h2>
            </div>
                <div class="swiper-container-small2">
                    <!-- swiper slides -->
                    <div class="swiper-wrapper">
                        <div class="swiper-slide" ">                        
                            <div class="image-layer" ><img src="./assets/img/iliter-2.jpg" alt=""></div>
                            <div class="text_contents">
                                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Velit dolore incidunt ipsum aperiam tempore doloribus porro illum harum fuga optio labore ad, molestias quasi, totam repellat veritatis sequi nostrum maiores!</p>
                                <div class="author">Ram Prasad Shrestha</div>
                            </div>
                        </div>

                        
                    </div>
                    <!-- !swiper slides -->
               

                    <!-- next / prev arrows -->
                    <div class="swiper-button-next swiper-button-next-small2"></div>
                    <div class="swiper-button-prev swiper-button-prev-small2"></div>
                    <!-- !next / prev arrows -->
            </div>
        </div>
    </section>


<!-- <section class="sectionTestimonial">
    <div class="container">
        <div class="blockHeading text-center">
            <div class="leadText">Faq</div>
            <h2 class="h2">Why Budhhist Circuit</h2>
        </div>

        <div class="col">
    <div class="tabs">
      <div class="tab">
        <input type="radio" id="rd1" name="rd">
        <label class="tab-label" for="rd1">Item 1</label>
        <div class="tab-content">
          Lorem, ipsum dolor sit amet consectetur adipisicing elit. Eos, facilis.
        </div>
      </div>
      <div class="tab">
        <input type="radio" id="rd2" name="rd">
        <label class="tab-label" for="rd2">Item 2</label>
        <div class="tab-content">
          Lorem ipsum dolor, sit amet consectetur adipisicing elit. Nihil, aut.
        </div>
      </div>
      <div class="tab">
        <input type="radio" id="rd3" name="rd">
        <label for="rd3" class="tab-close">Close others &times;</label>
      </div>
    </div>
  </div>
    </div>
</section> -->

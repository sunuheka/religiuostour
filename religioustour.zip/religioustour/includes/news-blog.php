<section id="news" class="sectionNews">
        <div class="container">
            <div class="blockHeading text-center">
                <div class="leadText">Blogs</div>
                <h2 class="h2">Latest News</h2>
            </div>

            <div class="row newsListing">
                <div class="col-sm-4">
                    <div class="newsItem">
                        <div class="newsImage">
                            <figure>
                                <img src="./assets/img/image.png" alt="">
                            </figure>
                            <div class="newsDate">21 jan</div>
                        </div>
                        <div class="newsContent">
                            <h3>Nepal Buddhist Religious Tour</h3>
                            <a href="#" class="btn-link">read more</a>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="newsItem">
                        <div class="newsImage">
                            <figure>
                                <img src="./assets/img/image.png" alt="">
                            </figure>
                            <div class="newsDate">21 jan</div>
                        </div>
                        <div class="newsContent">
                            <h3>Nepal Buddhist Religious Tour</h3>
                            <a href="#" class="btn-link">read more</a>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="newsItem">
                        <div class="newsImage">
                            <figure>
                                <img src="./assets/img/image.png" alt="">
                            </figure>
                            <div class="newsDate">21 jan</div>
                        </div>
                        <div class="newsContent">
                            <h3>Nepal Buddhist Religious Tour</h3>
                            <a href="#" class="btn-link">read more</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
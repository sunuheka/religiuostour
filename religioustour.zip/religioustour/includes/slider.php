<section class="sectionSliderSmall">
        <div class="container">
            <div class="sliderHeader">
             <h3 class="darkblue">HONOURS NICCI HAS RECEIVED</h3>
            </div>

            <div class="swiper-container-small">
                <!-- swiper slides -->
                <div class="swiper-wrapper " id="lightgallery">
                    <div class="swiper-slide" data-src="./assets/img/imgb1.jpg">
                        <a href="">
                            <div class="slidersmall_contents">
                                <div class="slidersmall_image">
                                    <img src="./assets/img/imgb1.jpg" alt="banner" />
                                </div>
                            </div>
                        </a>
                    </div>

                    <div class="swiper-slide" data-src="./assets/img/imgb2.jpg">
                        <a href="">
                            <div class="slidersmall_contents">  
                                <div class="slidersmall_image">
                                    <img src="./assets/img/imgb2.jpg" alt="banner" />
                                </div>
                            </div>
                        </a>
                    </div>

                    <div class="swiper-slide" data-src="./assets/img/imgb3.jpg">
                        <a href="">
                            <div class="slidersmall_contents">
                                <div class="slidersmall_image">
                                    <img src="./assets/img/imgb3.jpg" alt="banner" />
                                </div>
                            </div>
                        </a>
                    </div>

                    <div class="swiper-slide" data-src="./assets/img/imgb4.jpg">
                        <a href="">
                            <div class="slidersmall_contents">
                                <div class="slidersmall_image">
                                    <img src="./assets/img/imgb4.jpg" alt="banner" />
                                </div>
                            </div>
                        </a>
                    </div>

                    <div class="swiper-slide" data-src="./assets/img/imgb5.jpg">
                        <a href="">
                            <div class="slidersmall_contents">
                                <div class="slidersmall_image">
                                    <img src="./assets/img/imgb5.jpg" alt="banner" />
                                </div>
                            </div>
                        </a>
                    </div>

                    <div class="swiper-slide" data-src="./assets/img/imgb6.jpg">
                        <a href="">
                            <div class="slidersmall_contents">
                                <div class="slidersmall_image">
                                    <img src="./assets/img/imgb6.jpg" alt="banner" />
                                </div>
                            </div>
                        </a>
                    </div>
                </div>
                <!-- !swiper slides -->
            </div>

            <!-- next / prev arrows -->
            <div class="swiper-button-prev swiper-button-next-small"></div>
            <div class="swiper-button-next swiper-button-prev-small"></div>
            <!-- !next / prev arrows -->
        </div>
    </section>
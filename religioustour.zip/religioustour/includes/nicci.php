<section class="sectionNicci">
        <div class="container">
            <div class="row">
            <div class="col-sm-6 nicciImage">
                <div class="nicciHeading animation__start-block">
                    <div class="leadText">trusted & professional</div>
                    <h3>We are trusted by <span class="colorBlue">NICCI</span></h3>
                </div>
                    <figure class="animation__start-block">
                        <img src="./assets/img/nicci.png" alt="">
                    </figure>
                <div class="nicciComment">
                    We only choose best for you.
                </div>
            </div>
            <div class="col-sm-6 nicciContent animation__start-block">
                <figure>
                    <img src="./assets/img/img.png" alt="">
                </figure>
            </div>
        </div>
    </div>
    </section>
<div class="search-section">
<div class="container d-flex justify-content-end">
    <form method="post" id="" class="d-flex input-group" action="">
        <input type="search" value="" name="searchtext" id="searchtext" class="form-control"
            placeholder="Search" required="">
        <button type="submit" class="search-submit btn btn-primary">Search</button>
    </form>
</div>
</div>
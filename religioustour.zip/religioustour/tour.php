<?php include 'includes/metahead.php';?>

<body class="tour">
    <?php include 'includes/header.php';?>
    
   
<section class="contentBlock text-center">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-sm-7 wrapper-760">
                <div class="blockHeading">
                    <h2 style="color: #e19c1e;">Under Construction</h2>
                </div>
                
                
            </div>
        </div>
    </div>
</section>


    
    <?php include 'includes/footer.php';?>
    <?php include 'includes/scripts.php';?>
</body>

</html>